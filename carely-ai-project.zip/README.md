# Carely AI – Health Copilot

A single-page chat app where an animated chibi doctor (Dr. Carely) answers health questions.

## Files
| File | What it does |
|---|---|
| `index.html` | Page layout: sidebar, character stage, chat panel |
| `styles.css` | All styling and the character animations |
| `app.js` | Chat logic, saved chats, health profile, voice, character state machine |
| `assets/` | Character art: `h_*.png` = heads/expressions, `b_*.png` = bodies/arm poses, `b_back.png` = back view |
| `server.py` | Optional local server that forwards chat to the Anthropic API |

## Run it
```
export ANTHROPIC_API_KEY=sk-ant-...   # Windows PowerShell: $env:ANTHROPIC_API_KEY="sk-ant-..."
python server.py
```
Open http://localhost:8000. Without a key the app still runs and uses a small built-in fallback reply.
Use Chrome or Edge for voice input (🎤). Chats and the health profile are stored only in the browser (localStorage).

## How the character works (app.js)
- `EXP` lists each state: idle (`happy`), typing (`look`), `think`, `speak`, `puzzled`, `supportive`, `away`.
- A character = one **body** image (arm pose) + one **head** image (expression). `setExp(state)` picks them.
- Speaking cycles head images for mouth shapes and body images for arm gestures; glances at his message every ~5 s.
- Idle adds blinking, an occasional open-arm gesture, and a back-turned rest pose after 30 s of inactivity.
- CSS keyframes in `styles.css` (`breathe`, `headbob`, `talkmove`, ...) add the continuous body motion.
- `askModel(prompt)` is the only place that talks to an AI; change `CONFIG.endpoint` or replace it with your own backend.

Dr. Carely gives general guidance only, not a diagnosis.
