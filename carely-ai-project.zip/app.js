/* ---------- AI connection ----------
   Dr. Carely's replies come from askModel(prompt) -> returns the reply text.
   - Inside a Claude artifact it uses window.claude.
   - Otherwise it POSTs {prompt} to CONFIG.endpoint (see server.py) and expects {text}.
   - If both fail, a small built-in fallback answers (see fallback()). */
const CONFIG={endpoint:"/api/chat"};
async function askModel(prompt){
 try{if(window.claude){const sm=await window.claude.use("sample");if(sm){const r=await sm(prompt,{cache:false,modelTier:"quick"});return((r&&r.text)||"").trim()}}}catch(e){}
 try{const r=await fetch(CONFIG.endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt})});if(r.ok){const d=await r.json();return(d.text||"").trim()}}catch(e){}
 return""}

const IMG={
 "h": {
  "happy": "assets/h_happy.png",
  "gaze": "assets/h_gaze.png",
  "blink": "assets/h_blink.png",
  "say_c": "assets/h_say_c.png",
  "say_b": "assets/h_say_b.png",
  "say_a": "assets/h_say_a.png"
 },
 "b": {
  "b_down": "assets/b_b_down.png",
  "b_left": "assets/b_b_left.png",
  "b_open": "assets/b_b_open.png",
  "b_wide": "assets/b_b_wide.png",
  "back": "assets/b_back.png"
 }
};
const EXP={happy:{m:"idle",t:"Happy to help",h:"happy",b:"b_down"},look:{m:"look",t:"Reading what you type",h:"gaze",b:"b_down"},think:{m:"think",t:"Thinking…",h:"gaze",b:"b_down"},speak:{m:"speak",t:"Explaining",h:"happy",b:"b_open"},puzzled:{m:"idle",t:"Hmm, tell me more",h:"gaze",b:"b_down"},supportive:{m:"cheer",t:"You've got this",h:"say_a",b:"b_wide"},away:{m:"idle",t:"Resting…",f:"back"}};
const $=s=>document.querySelector(s);
let S=null;try{S=JSON.parse(localStorage.getItem("carely"))}catch(e){}
if(!S)S={chats:[],active:null,profile:{}};
const save=()=>{try{localStorage.setItem("carely",JSON.stringify(S))}catch(e){}};
const sleep=ms=>new Promise(r=>setTimeout(r,ms)),bd=$("#bd"),hd=$("#hd");
for(const[k,v]of Object.entries(IMG.b)){const i=document.createElement("img");i.src=v;i.alt="";i.dataset.k=k;bd.appendChild(i)}
for(const[k,v]of Object.entries(IMG.h)){const i=document.createElement("img");i.src=v;i.alt="";i.dataset.k=k;hd.appendChild(i)}
let expT,talkT,gestT,cur0="happy",lastAct=Date.now(),curH="happy";
function showH(k){curH=k;hd.querySelectorAll("img").forEach(i=>i.classList.toggle("on",i.dataset.k===k))}
function showB(k){bd.querySelectorAll("img").forEach(i=>i.classList.toggle("on",i.dataset.k===k))}
function setExp(k,hold){clearTimeout(expT);clearTimeout(talkT);clearTimeout(gestT);cur0=k;const e=EXP[k];$("#sb").dataset.mode=e.m;$("#sub").textContent=e.t;
 if(e.f){showH(null);showB(e.f)}else{showH(e.h);showB(e.b)}
 if(k==="speak"){const H=["say_a","happy","say_b","say_c","happy","say_a","say_b","happy"],B=["b_open","b_down","b_wide","b_left","b_open"];let n=0,m=0;
  const st=()=>{if((Date.now()/1000)%5<1.4){showH("gaze");talkT=setTimeout(st,250)}else{showH(H[n++%H.length]);talkT=setTimeout(st,160+Math.random()*130)}};
  const sg=()=>{showB(B[m++%B.length]);gestT=setTimeout(sg,1500)};st();sg()}
 if(k==="happy"){const g=()=>{gestT=setTimeout(()=>{if(cur0==="happy"){showB("b_open");showH("say_a");gestT=setTimeout(()=>{if(cur0==="happy"){showB("b_down");showH("happy")}g()},1600)}else g()},6000+Math.random()*5000)};g()}
 if(hold)expT=setTimeout(()=>setExp("happy"),hold)}
setExp("happy");
(function bl(){setTimeout(()=>{if(curH==="happy"){hd.querySelector('[data-k=blink]').classList.add("on");hd.querySelector('[data-k=happy]').classList.remove("on");setTimeout(()=>{if(curH==="happy")showH("happy")},120)}bl()},2600+Math.random()*3400)})();
const wake=()=>{lastAct=Date.now();if(cur0==="away")setExp("happy")};
addEventListener("keydown",wake);addEventListener("mousedown",wake);addEventListener("mousemove",wake);
setInterval(()=>{if(cur0==="happy"&&!busy&&Date.now()-lastAct>30000)setExp("away")},3000);
let tab="chats",busy=false,voice=false,speaking=false;
const cur=()=>S.chats.find(c=>c.id===S.active);
function newChat(){const c={id:Date.now()+"",title:"New chat",msgs:[]};S.chats.unshift(c);S.active=c.id;save();tab="chats";render();$("#inp").focus();return c}
function greet(){const n=(S.profile.name||"").trim();return"Hi"+(n?" "+n:"")+"! I'm Dr. Carely. How are you feeling today?"}
function renderSide(){const el=$("#side");el.innerHTML="";document.querySelectorAll(".tabs button").forEach(b=>b.classList.toggle("on",b.dataset.t===tab));
 if(tab==="chats"){if(!S.chats.length)el.innerHTML='<div class="note">No chats yet. Say hello!</div>';
  S.chats.forEach(c=>{const b=document.createElement("div");b.className="item"+(c.id===S.active?" on":"");const s=document.createElement("span");s.textContent=c.title;s.style.cursor="pointer";s.onclick=()=>{S.active=c.id;save();render()};const x=document.createElement("button");x.className="x";x.textContent="✕";x.onclick=()=>{S.chats=S.chats.filter(z=>z.id!==c.id);if(S.active===c.id)S.active=S.chats[0]?S.chats[0].id:null;save();render()};b.append(s,x);el.appendChild(b)})}
 else if(tab==="guide"){[["😴","Better sleep","How can I sleep better?"],["💧","Staying hydrated","How much water should I drink each day?"],["🤕","Headaches","I have a headache. What can I do?"],["🤧","Cold & flu","I think I'm catching a cold. What should I do?"],["🧘","Stress & anxiety","I feel stressed. Any simple ways to calm down?"],["🥗","Healthy eating","How do I eat healthier in a simple way?"],["🏃","Staying active","How can I start exercising safely?"],["🩹","First aid basics","What are basic first aid steps for a minor cut or burn?"]].forEach(([e,t,q])=>{const b=document.createElement("button");b.className="topic";b.innerHTML="<b>"+e+" "+t+"</b><small>Tap to ask Dr. Carely</small>";b.onclick=()=>{newChat();send(q)};el.appendChild(b)})}
 else{const F=[["name","Name"],["age","Age"],["blood","Blood group"],["allergies","Allergies"],["conditions","Health conditions"],["meds","Current medications"],["notes","Other notes"]];
  F.forEach(([k,l])=>{const d=document.createElement("div");d.innerHTML="<label>"+l+"</label>";const i=document.createElement(["notes","conditions","meds","allergies"].includes(k)?"textarea":"input");if(i.tagName==="TEXTAREA")i.rows=2;i.value=S.profile[k]||"";i.oninput=()=>{S.profile[k]=i.value;save()};d.appendChild(i);el.appendChild(d)});
  const n=document.createElement("div");n.className="note";n.textContent="Saved only in this browser. Dr. Carely uses it to personalise advice.";el.appendChild(n)}}
function bubble(r,t){const d=document.createElement("div");d.className="m "+(r==="user"?"u":"a");d.textContent=t;$("#msgs").appendChild(d);$("#msgs").scrollTop=1e9;return d}
function renderChat(){const c=cur();$("#msgs").innerHTML="";bubble("assistant",greet());if(c)c.msgs.forEach(m=>bubble(m.role,m.text));
 const ch=$("#chips");ch.innerHTML="";if(!c||!c.msgs.length)["I have a headache","I can't sleep well","I feel stressed","Healthy eating tips"].forEach(t=>{const b=document.createElement("button");b.textContent=t;b.onclick=()=>send(t);ch.appendChild(b)})}
function render(){renderSide();renderChat()}
function fallback(t){t=t.toLowerCase();if(/chest pain|can't breathe|cannot breathe|faint|suicid|stroke|bleeding heavily/.test(t))return"That sounds serious, and I'm concerned. Please call your local emergency number or get to the nearest hospital right now.";
 if(/headache/.test(t))return"I'm sorry you're hurting. Rest in a quiet, dim room, drink some water, and try a cool cloth on your forehead. If it's sudden and severe, or comes with fever or confusion, please see a doctor.";
 if(/sleep/.test(t))return"Poor sleep is tough. Try a fixed bedtime, no screens for an hour before bed, and a cool dark room. Would you like more tips?";
 return"I'm here with you. Could you tell me a bit more, like when it started and how strong it feels?"}
function profText(){const p=S.profile,o=[];for(const[k,l]of[["name","Name"],["age","Age"],["blood","Blood group"],["allergies","Allergies"],["conditions","Conditions"],["meds","Medications"],["notes","Notes"]])if(p[k])o.push(l+": "+p[k]);return o.join("; ")||"none provided"}
async function send(text){text=(text||"").trim();if(!text||busy)return;busy=true;speechSynthesis.cancel();
 const c=cur()||newChat();c.msgs.push({role:"user",text});if(c.title==="New chat")c.title=text.slice(0,32);save();$("#inp").value="";$("#chips").innerHTML="";bubble("user",text);renderSide();
 setExp("think");const t0=Date.now();
 const hist=c.msgs.slice(-9,-1).map(m=>(m.role==="user"?"Patient: ":"Dr. Carely: ")+m.text).join("\n");
 const prompt="You are Dr. Carely, a warm, caring virtual health assistant (a friendly chibi doctor). Reply in 2-4 short, plain sentences, no jargon, no markdown (up to 5 short sentences if the patient asks you to explain a topic). Always show brief concern for how the patient feels first. Give clear, practical self-care guidance. Ask at most one short follow-up question when useful. Never claim to diagnose; for serious or emergency signs (chest pain, trouble breathing, stroke signs, heavy bleeding, thoughts of self-harm) calmly tell them to contact emergency services now. Patient health info: "+profText()+"\n\nConversation so far:\n"+hist+"\nPatient: "+text+"\nDr. Carely:";
 const ask=askModel(prompt);
 const reply=(await ask)||fallback(text);await sleep(Math.max(0,2600-(Date.now()-t0)));
 const out=bubble("assistant","");c.msgs.push({role:"assistant",text:reply});save();setExp("speak");
 let tts=Promise.resolve();if(voice&&"speechSynthesis"in window)tts=new Promise(r=>{const u=new SpeechSynthesisUtterance(reply);u.onend=u.onerror=r;speechSynthesis.speak(u)});
 for(let i=1;i<=reply.length;i++){out.textContent=reply.slice(0,i);$("#msgs").scrollTop=1e9;await sleep(i%12===0?70:22)}
 await tts;busy=false;setExp(/\?\s*$/.test(reply)?"puzzled":"supportive",2600)}
let tT;$("#inp").addEventListener("input",()=>{if(busy)return;clearTimeout(tT);if(!$("#inp").value){setExp("happy");return}if(cur0!=="look")setExp("look");tT=setTimeout(()=>{if(!busy)setExp("happy")},1200)});
$("#inp").addEventListener("keydown",e=>{if(e.key==="Enter")send($("#inp").value)});
$("#go").onclick=()=>send($("#inp").value);$("#new").onclick=newChat;
document.querySelectorAll(".tabs button").forEach(b=>b.onclick=()=>{tab=b.dataset.t;renderSide()});
$("#vol").onclick=()=>{voice=!voice;$("#vol").textContent=voice?"🔊":"🔈";$("#vol").classList.toggle("on",voice);if(!voice)speechSynthesis.cancel()};
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
if(!SR)$("#mic").style.display="none";else{const r=new SR();r.lang="en-US";r.interimResults=false;let on=false;
 r.onresult=e=>{$("#inp").value=e.results[0][0].transcript;send($("#inp").value)};r.onend=()=>{on=false;$("#mic").classList.remove("on")};
 $("#mic").onclick=()=>{if(on){r.stop();return}try{r.start();on=true;$("#mic").classList.add("on");setExp("look")}catch(e){}}}
render();
