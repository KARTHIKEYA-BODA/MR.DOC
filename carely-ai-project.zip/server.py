"""Tiny local server for Carely AI (no dependencies).
Serves the web app and forwards chat prompts to the Anthropic API so your key stays on the server.

  export ANTHROPIC_API_KEY=sk-ant-...        (Windows PowerShell: $env:ANTHROPIC_API_KEY="sk-ant-...")
  python server.py
  open http://localhost:8000
"""
import json, os, urllib.request
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
MODEL = os.environ.get("CARELY_MODEL", "claude-sonnet-5-5")  # any current Claude model name
PORT = int(os.environ.get("PORT", "8000"))


class Handler(SimpleHTTPRequestHandler):
    def do_POST(self):
        if self.path != "/api/chat":
            return self.send_error(404)
        try:
            size = int(self.headers.get("Content-Length", 0))
            prompt = json.loads(self.rfile.read(size))["prompt"]
            req = urllib.request.Request(
                "https://api.anthropic.com/v1/messages",
                data=json.dumps({
                    "model": MODEL,
                    "max_tokens": 400,
                    "messages": [{"role": "user", "content": prompt}],
                }).encode(),
                headers={
                    "x-api-key": API_KEY,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
            )
            with urllib.request.urlopen(req, timeout=60) as r:
                data = json.loads(r.read())
            text = "".join(b.get("text", "") for b in data.get("content", []))
            self.reply(200, {"text": text})
        except Exception as e:  # the app shows its built-in fallback reply if this fails
            self.reply(500, {"error": str(e)})

    def reply(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


if __name__ == "__main__":
    if not API_KEY:
        print("Warning: ANTHROPIC_API_KEY is not set - the app will use its simple fallback replies.")
    print(f"Carely AI running at http://localhost:{PORT}")
    ThreadingHTTPServer(("", PORT), Handler).serve_forever()
