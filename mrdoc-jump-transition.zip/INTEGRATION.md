# Mr.Doc jump transition – how to plug it in

Files
- doctor-jump.js                      -> put next to app.js
- assets/doctor-jump-sheet.webp       -> 32-frame sprite sheet (transparent)
- assets/doctor-stand.png             -> last frame; use as the standing doctor on EVERY page
- demo.html                           -> working demo (run: python -m http.server, open demo.html)

1) index.html
   - add before app.js:  <script src="doctor-jump.js"></script>
   - .auth-character img  src -> assets/doctor-stand.png
   - .intro-poster-figure img src -> assets/doctor-stand.png

2) app.js
   - line ~3316: $(".intro-poster-figure img").src = "assets/doctor-stand.png";
   - delete the old travelDoctor element + travelCharacter() (lines ~3322-3385)
   - showAuth(): replace the travelCharacter(...) call with
       DoctorJump.fly({
         from: $(".intro-poster-figure img"),
         to:   $(".auth-character img"),
         outCard: $(".intro-cta"),
         inCard:  $(".auth-card"),
         onLand: () => { introScreen.classList.remove("auth-transitioning"); }
       });
     and remove your old CSS flip (.auth-transitioning / .is-entering) so the cards don't flip twice.
   - #auth-back handler: same call with from/to swapped, outCard .auth-card, inCard .intro-cta,
     and onLand: () => { authScreen.hidden = true; }
   - the target page must be displayed (not hidden/display:none) when fly() starts.

3) Tweaks (top of doctor-jump.js): SCHEDULE (ms per frame), ANTICIPATION_MS, `speed` option, `arc` option (jump height in px).
