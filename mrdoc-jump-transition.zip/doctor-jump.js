/* doctor-jump.js — Mr.Doc jumps from one page to the next.
 *
 * Plays the 32-frame sprite (assets/doctor-jump-sheet.webp) on a single
 * flying clone: stand -> squash -> crouch -> leap (pose swaps in mid-air)
 * -> land -> stand up, while the old card flips away and the new card
 * flips in. Everything runs on one clock so the jump, the arc and the
 * card flips stay in sync.
 *
 *   DoctorJump.fly({
 *     from:    <img>,   // standing doctor on the page you are leaving
 *     to:      <img>,   // standing doctor on the page you are entering
 *     outCard: <el>,    // optional: card that flips away
 *     inCard:  <el>,    // optional: card that flips in
 *   }).then(() => { ... });
 *
 * `from` and `to` must show assets/doctor-stand.png (the last sprite
 * frame) so the hand-over between the real image and the clone is
 * invisible. Both must be laid out (not display:none) when fly() runs.
 */
(function (root) {
  "use strict";

  const SHEET = {
    url: "assets/doctor-jump-sheet.webp",
    cols: 8, rows: 4, fw: 187, fh: 332,
    groundY: 323, // feet line inside a frame (px from frame top)
    headX: 100,   // horizontal centre of the character inside a frame
  };

  // [first frame, last frame, ms per frame] — source was 24 fps (~42 ms/frame).
  // Slightly slower than the source so each pose is readable on screen.
  const SCHEDULE = [
    [0, 3, 62],    // crouch
    [4, 7, 52],    // push off, arms swing up
    [8, 14, 58],   // flight
    [15, 17, 52],  // coming down
    [18, 26, 50],  // touch down + recover
    [27, 31, 70],  // stand up straight
  ];
  const ANTICIPATION_MS = 130; // stand -> squat before the crouch frames
  const LAUNCH_FRAME = 4;      // feet leave the ground
  const TOUCH_FRAME = 18;      // feet hit the ground again

  const reduced = () =>
    typeof matchMedia === "function" &&
    matchMedia("(prefers-reduced-motion: reduce)").matches;

  let sheetReady = null;
  function loadSheet(url) {
    if (sheetReady) return sheetReady;
    sheetReady = new Promise((resolve) => {
      const img = new Image();
      img.onload = () => (img.decode ? img.decode().catch(() => {}) : 0, resolve(true));
      img.onerror = () => resolve(false);
      img.src = url;
    });
    return sheetReady;
  }

  function injectCSS() {
    if (document.getElementById("dj-css")) return;
    const s = document.createElement("style");
    s.id = "dj-css";
    s.textContent = `
      .dj-layer{position:fixed;inset:0;z-index:9999;pointer-events:none;overflow:hidden}
      .dj-doc{position:absolute;left:0;top:0;will-change:transform;
        background-repeat:no-repeat}
      .dj-shadow{position:absolute;left:0;top:0;border-radius:50%;will-change:transform,opacity;
        background:radial-gradient(closest-side,rgba(20,70,80,.28),rgba(20,70,80,0))}
      .dj-hide{visibility:hidden !important}
    `;
    document.head.appendChild(s);
  }

  // Box the character really occupies inside an <img> (handles object-fit: contain).
  function fitBox(el) {
    const r = el.getBoundingClientRect();
    const k = Math.min(r.width / SHEET.fw, r.height / SHEET.fh);
    const w = SHEET.fw * k, h = SHEET.fh * k;
    const left = r.left + (r.width - w) / 2, top = r.top + (r.height - h) / 2;
    return { k, footX: left + SHEET.headX * k, footY: top + SHEET.groundY * k };
  }

  const smooth = (u) => u * u * (3 - 2 * u);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  function flipCards(outCard, inCard, speed) {
    const P = "perspective(1500px)";
    const jobs = [];
    if (outCard) {
      jobs.push(outCard.animate(
        [
          { transform: `${P} rotateY(0deg) translateX(0)`, opacity: 1 },
          { transform: `${P} rotateY(-38deg) translateX(-14px)`, opacity: 1, offset: .45 },
          { transform: `${P} rotateY(-92deg) translateX(-34px)`, opacity: 0 },
        ],
        { duration: 560 * speed, delay: 40 * speed, easing: "cubic-bezier(.5,0,.8,.45)", fill: "forwards" }
      ));
    }
    if (inCard) {
      jobs.push(inCard.animate(
        [
          { transform: `${P} rotateY(88deg) translateX(34px)`, opacity: 0 },
          { transform: `${P} rotateY(30deg) translateX(10px)`, opacity: 1, offset: .5 },
          { transform: `${P} rotateY(0deg) translateX(0)`, opacity: 1 },
        ],
        { duration: 700 * speed, delay: 420 * speed, easing: "cubic-bezier(.2,.8,.25,1)", fill: "both" }
      ));
    }
    return jobs;
  }

  async function fly(opts) {
    const { from, to, outCard = null, inCard = null, speed = 1, arc } = opts;
    const done = (opts.onLand || (() => {}));
    const swapDone = () => { from && from.classList.remove("dj-hide"); };

    if (!from || !to || reduced() || !(await loadSheet(opts.sheet || SHEET.url))) {
      // No motion: just swap the pages.
      if (outCard) outCard.style.visibility = "hidden";
      if (inCard) { inCard.style.opacity = ""; inCard.style.visibility = ""; }
      swapDone(); done();
      return;
    }
    injectCSS();

    const A = fitBox(from), B = fitBox(to);

    // ---- timeline -------------------------------------------------------
    const frames = []; // {f, t0}
    let t = ANTICIPATION_MS * speed;
    for (const [a, b, ms] of SCHEDULE)
      for (let f = a; f <= b; f++) { frames.push({ f, t0: t }); t += ms * speed; }
    const total = t;
    const tLaunch = frames.find((x) => x.f === LAUNCH_FRAME).t0;
    const tTouch = frames.find((x) => x.f === TOUCH_FRAME).t0;

    const dist = Math.hypot(B.footX - A.footX, B.footY - A.footY);
    const arcH = arc != null ? arc : clamp(dist * 0.1, 26, 90);

    // ---- build layer ----------------------------------------------------
    const layer = document.createElement("div"); layer.className = "dj-layer";
    const shadow = document.createElement("div"); shadow.className = "dj-shadow";
    const doc = document.createElement("div"); doc.className = "dj-doc";
    doc.style.cssText += `width:${SHEET.fw}px;height:${SHEET.fh}px;` +
      `background-image:url(${opts.sheet || SHEET.url});` +
      `background-size:${SHEET.fw * SHEET.cols}px ${SHEET.fh * SHEET.rows}px;` +
      `transform-origin:${SHEET.headX}px ${SHEET.groundY}px;`;
    shadow.style.width = "120px"; shadow.style.height = "26px";
    layer.append(shadow, doc); document.body.appendChild(layer);

    let lastFrame = -1;
    const setFrame = (f) => {
      if (f === lastFrame) return; lastFrame = f;
      doc.style.backgroundPosition = `${-(f % SHEET.cols) * SHEET.fw}px ${-Math.floor(f / SHEET.cols) * SHEET.fh}px`;
    };
    setFrame(31);
    from.classList.add("dj-hide");
    to.classList.add("dj-hide");
    if (outCard || inCard) {
      if (inCard) { inCard.style.visibility = ""; inCard.style.opacity = "0"; }
      flipCards(outCard, inCard, speed);
    }

    // ---- one clock drives everything -----------------------------------
    return new Promise((resolve) => {
      const t0 = performance.now();
      let landed = false;
      function tick(now) {
        const el = now - t0;
        let u = clamp((el - tLaunch) / (tTouch - tLaunch), 0, 1);
        const p = 0.5 * u + 0.5 * smooth(u);        // mostly even speed, soft ends
        const lift = arcH * 4 * u * (1 - u);        // extra screen-space arc
        const k = A.k + (B.k - A.k) * p;

        // pose
        let f = 31, sx = 1, sy = 1;
        if (el < ANTICIPATION_MS * speed) {         // stand -> squat
          const q = smooth(el / (ANTICIPATION_MS * speed));
          sx = 1 + 0.05 * q; sy = 1 - 0.07 * q;
        } else {
          for (let i = frames.length - 1; i >= 0; i--) if (el >= frames[i].t0) { f = frames[i].f; break; }
        }
        setFrame(f);

        // a little stretch on take-off, squash on touch-down
        if (u > 0 && u < 1) { const s = Math.sin(Math.PI * u); sx *= 1 - 0.02 * s; sy *= 1 + 0.03 * s; }
        const tilt = u > 0 && u < 1 ? Math.sin(Math.PI * u * 2) * 2.2 * Math.sign(B.footX - A.footX || 1) : 0;

        const fx = A.footX + (B.footX - A.footX) * p;
        const fy = A.footY + (B.footY - A.footY) * p - lift;
        doc.style.transform =
          `translate(${fx - SHEET.headX}px,${fy - SHEET.groundY}px) rotate(${tilt}deg) scale(${k * sx},${k * sy})`;

        // contact shadow stays on the floor and fades while he is high up
        const gy = A.footY + (B.footY - A.footY) * p;
        const sw = clamp(1 - lift / (arcH * 2.2), .35, 1);
        const fadeOut = clamp((total - el) / 260, 0, 1);   // fade the floor shadow before the hand-over
        shadow.style.opacity = String(sw * fadeOut);
        shadow.style.transform =
          `translate(${fx - 60}px,${gy - 13}px) scale(${k * 0.95 * sw},${k})`;

        if (!landed && el >= tTouch) { landed = true; }
        if (el >= total) {
          to.classList.remove("dj-hide");
          if (inCard) { inCard.getAnimations().forEach((a) => a.finish()); inCard.style.opacity = ""; }
          if (outCard) outCard.style.visibility = "hidden";
          done();                                  // caller hides the old page here
          from.classList.remove("dj-hide");        // ...so this cannot flash a second doctor
          layer.remove();
          resolve();
          return;
        }
        requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
    });
  }

  root.DoctorJump = { fly, preload: () => loadSheet(SHEET.url), SHEET };
})(window);
